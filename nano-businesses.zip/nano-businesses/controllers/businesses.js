const businesses = require('../models').businesses;

module.exports = {

  add(req, res) {
    return businesses
    .create({
      name: req.body.name,
      description: req.body.description,
      link: req.body.link
    })
    .then((result) => res.status(201).send(result))
    .catch((error) => res.status(400).send(error))
  },

  list(req, res) {
    return businesses
    .findAll()
    .then((result) => res.status(201).send(result))
    .catch((error) => res.status(400).send(error))

  },

  update(req, res) {
    return businesses

    .find({
      where: {
        name: req.params.name,
      },
    })

    .then((result) => {

      if (!result) {
        return res.status(404).send({
          message: 'Business Not Found'
        });
      }

      return result

      .update({
          description: req.body.description || result.description
       })

        .then(updatedTodoItem => res.status(200).send(updatedTodoItem))
        .catch(error => res.status(400).send(error))

      })

      .catch(error => res.status(400).send(error))

    },

  destroy(req, res) {
    return businesses

    .find({
      where: {
        name: req.params.name,
      },
    })

    .then(result => {
      if (!result) {
            return res.status(404).send({
            message: 'TodoItem Not Found'
        })
      }

      return result
      .destroy()
      .then(() => res.status(204).send())
      .catch(error => res.status(400).send(error))

    })

      .catch(error => res.status(400).send(error))

  },

}
