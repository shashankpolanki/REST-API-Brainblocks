var express = require('express');
var router = express.Router();
const businessesController = require('../controllers').businesses

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/api/businesses', businessesController.list)
router.post('/api/businesses', businessesController.add)
router.put('/api/businesses/:name', businessesController.update)
router.delete('/api/businesses/:name', businessesController.destroy)

module.exports = router;
