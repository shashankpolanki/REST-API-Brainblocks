const businesses = require('./businesses');

module.exports = {
  businesses,
};
